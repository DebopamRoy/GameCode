// void setup() {
//   // put your setup code here, to run once:
//   Serial.begin(115200);
//   Serial.println("Hello, ESP32!");
// }

// void loop() {
//   // put your main code here, to run repeatedly:
//   delay(10); // this speeds up the simulation
// }
/*
   ANDROID GAMEPAD
   {A=1, B=2, C=3, X=4, Y=5, Z=6, L1=7, R1=8, L2=9, R2=10,
   Select=11, Start=12, PS=13, L3=14 , R3=15}

   PS GAMEPAD MODE
   {SQUARE=1, X=2, CIRCLE=3, TRIANGLE=4, L1=5, R1=6, L2=7, R2=8,
   Select=9, Start=10, L3=11, R3=12, PS=13}

*/


#include <Arduino.h>
// #include <FakeBleGamepad.h>


//ABXY BUTTONS
#define X_BUTTON 15         // A
#define CIRCLE_BUTTON 17    // B
#define TRIANGLE_BUTTON 4  // Y
#define SQUARE_BUTTON 5    // X

//TRIGGERS
#define R1_BUTTON 18
#define R2_BUTTON 19
#define L1_BUTTON 21
#define L2_BUTTON 22

//MENU BUTTONS
#define START_BUTTON 23
#define SELECT_BUTTON 26
#define PS_BUTTON 25

//JOYSTICKS BUTTONS
#define R3_BUTTON 33
#define L3_BUTTON 32

//JOYSTICKS
//Right
#define RIGHT_VRX_JOYSTICK 12
#define RIGHT_VRY_JOYSTICK 13
//Left
#define LEFT_VRX_JOYSTICK 14
#define LEFT_VRY_JOYSTICK 27


#define NUM_BUTTONS 13

//The order of these three arrays matters a lot, be carefully when changing them
int buttonsPins[NUM_BUTTONS] = {X_BUTTON, CIRCLE_BUTTON, TRIANGLE_BUTTON, SQUARE_BUTTON,
                                R1_BUTTON, R2_BUTTON, L1_BUTTON, L2_BUTTON,
                                START_BUTTON, SELECT_BUTTON, PS_BUTTON,
                                R3_BUTTON, L3_BUTTON
                               };

//There is not buttons for Y and Z
int androidGamepadButtons[NUM_BUTTONS] = {1, 2, 3, 4, 8, 10, 7, 9, 12, 11, 13, 15, 14};
int PS1GamepadButtons[NUM_BUTTONS] = {2, 3, 4, 1, 6, 8, 5, 7, 10, 9, 13, 12, 11};
int PCGamepadButtons[NUM_BUTTONS] = {1, 2, 4, 3, 6, 8, 5, 7, 10, 9, 0, 12, 11};


uint16_t leftVrxJoystickLecture = 0;
uint16_t leftVryJoystickLecture = 0;
uint16_t rightVrxJoystickLecture = 0;
uint16_t rightVryJoystickLecture = 0;

uint16_t leftVrxJoystickValue = 0;
uint16_t leftVryJoystickValue = 0;
uint16_t rightVrxJoystickValue = 0;
uint16_t rightVryJoystickValue = 0;

// ***** CHANGED *****
#define DEADZONE 100


typedef enum {ANDROID, PS1, PC} GamepadModes;
GamepadModes gamepadMode = PC;

#define SIMULATION
#ifdef SIMULATION
#define CONTROLLER_TYPE_GAMEPAD 0

class FakeBleGamepadConfiguration
{
public:
    void setAutoReport(bool){}
    void setControllerType(int){}
    void setVid(int){}
    void setPid(int){}
    void setHatSwitchCount(int){}
};

class FakeBleGamepad
{
public:

    FakeBleGamepad(const char* name,const char* manufacturer){}

    void begin(FakeBleGamepadConfiguration* config=nullptr)
    {
        Serial.println("Fake BLE Started");
    }

    bool isConnected()
    {
        return true;
    }

    void press(uint8_t button)
    {
        Serial.print("PRESS ");
        Serial.println(button);
    }

    void release(uint8_t button)
    {
        Serial.print("RELEASE ");
        Serial.println(button);
    }

    void setX(int value)
    {
        Serial.print("X=");
        Serial.println(value);
    }

    void setY(int value)
    {
        Serial.print("Y=");
        Serial.println(value);
    }

    void setZ(int value)
    {
        Serial.print("Z=");
        Serial.println(value);
    }

    void setRX(int value)
    {
        Serial.print("RX=");
        Serial.println(value);
    }

    void setLeftThumb(int x,int y)
    {
        Serial.print("LX=");
        Serial.print(x);

        Serial.print(" LY=");
        Serial.println(y);
    }

    void setRightThumb(int x,int y)
    {
        Serial.print("RX=");
        Serial.print(x);

        Serial.print(" RY=");
        Serial.println(y);
    }

    void sendReport()
    {
        Serial.println("----------------");
    }

};
#define BleGamepad FakeBleGamepad
#define BleGamepadConfiguration FakeBleGamepadConfiguration


#else
#include <BleGamepad.h>
#endif


FakeBleGamepad bleGamepad("ESP32_BLE Gamepad", "ESP");
BleGamepadConfiguration bleGamepadConfig;

void joysticksHandlerForMobile(
uint16_t,
uint16_t,
uint16_t,
uint16_t);

void joysticksHandlerForPC(
uint16_t,
uint16_t,
uint16_t,
uint16_t);
void setup() {
  // put your setup code here, to run once:
  delay(1000);
  Serial.begin(115200);

  for (int i = 0; i < NUM_BUTTONS; i++) {
    pinMode(buttonsPins[i], INPUT_PULLUP);
  }

  bleGamepadConfig.setAutoReport(false);
  bleGamepadConfig.setControllerType(CONTROLLER_TYPE_GAMEPAD); // CONTROLLER_TYPE_JOYSTICK, CONTROLLER_TYPE_GAMEPAD (DEFAULT), CONTROLLER_TYPE_MULTI_AXIS
  bleGamepadConfig.setVid(0xe502);
  bleGamepadConfig.setPid(0xabcd);
  bleGamepadConfig.setHatSwitchCount(4);
  bleGamepad.begin(&bleGamepadConfig);
}

void loop() {
  // put your main code here, to run repeatedly:
  if (bleGamepad.isConnected()) {
    //Joysticks lecture
    leftVrxJoystickLecture = analogRead(LEFT_VRX_JOYSTICK);
    leftVryJoystickLecture = analogRead(LEFT_VRY_JOYSTICK);
    rightVrxJoystickLecture = analogRead(RIGHT_VRX_JOYSTICK);
    rightVryJoystickLecture = analogRead(RIGHT_VRY_JOYSTICK);

    // Serial.println(rightVrxJoystickLecture);

    // ***** CHANGED *****
    // Apply deadzone around centre

    if (abs((int)leftVrxJoystickLecture - 2048) < DEADZONE)
      leftVrxJoystickLecture = 2048;

    if (abs((int)leftVryJoystickLecture - 2048) < DEADZONE)
      leftVryJoystickLecture = 2048;

    if (abs((int)rightVrxJoystickLecture - 2048) < DEADZONE)
      rightVrxJoystickLecture = 2048;

    if (abs((int)rightVryJoystickLecture - 2048) < DEADZONE)
      rightVryJoystickLecture = 2048;

    // ***** CHANGED *****
    // Print every axis instead of only one

    Serial.print("LX: ");
    Serial.print(leftVrxJoystickLecture);

    Serial.print("  LY: ");
    Serial.print(leftVryJoystickLecture);

    Serial.print("  RX: ");
    Serial.print(rightVrxJoystickLecture);

    Serial.print("  RY: ");
    Serial.println(rightVryJoystickLecture);

    //Compute joysticks value
    leftVrxJoystickValue = map(leftVrxJoystickLecture, 4095, 0, 0, 32767);
    leftVryJoystickValue = map(leftVryJoystickLecture, 0, 4095, 0, 32767);
    rightVrxJoystickValue = map(rightVrxJoystickLecture, 4095, 0, 0, 32767);
    rightVryJoystickValue = map(rightVryJoystickLecture, 0, 4095, 0, 32767);


    switch (gamepadMode) {
      case ANDROID:
        for (int i = 0; i < NUM_BUTTONS; i++) {
          if (!digitalRead(buttonsPins[i])) {
            bleGamepad.press(androidGamepadButtons[i]);
          }
          else {
            bleGamepad.release(androidGamepadButtons[i]);
          }
        }
          joysticksHandlerForMobile(leftVrxJoystickValue, leftVryJoystickValue, rightVrxJoystickValue, rightVryJoystickValue);
        break;

      case PS1:
        for (int i = 0; i < NUM_BUTTONS; i++) {
          if (!digitalRead(buttonsPins[i])) {
            bleGamepad.press(PS1GamepadButtons[i]);
          }
          else {
            bleGamepad.release(PS1GamepadButtons[i]);
          }
        }
          joysticksHandlerForMobile(leftVrxJoystickValue, leftVryJoystickValue, rightVrxJoystickValue, rightVryJoystickValue);
        break;

      case PC:
        for (int i = 0; i < NUM_BUTTONS; i++) {
          if (!digitalRead(buttonsPins[i])) {
            bleGamepad.press(PCGamepadButtons[i]);
          }
          else {
            bleGamepad.release(PCGamepadButtons[i]);
          }
          // joysticksHandlerForPC(leftVrxJoystickValue, leftVryJoystickValue, rightVrxJoystickValue, rightVryJoystickValue);
        }
        // ***** CHANGED *****
        joysticksHandlerForPC(
          leftVrxJoystickValue,
          leftVryJoystickValue,
          rightVrxJoystickValue,
          rightVryJoystickValue);
        break;
    }

    bleGamepad.sendReport();
  }
  delay(300);
}

void joysticksHandlerForMobile(uint16_t leftVrx, uint16_t leftVry, uint16_t rightVrx, uint16_t rightVry) {
  bleGamepad.setLeftThumb(leftVrx, leftVry);
  bleGamepad.setRightThumb(rightVrx, rightVry);
}

void joysticksHandlerForPC(uint16_t leftVrx, uint16_t leftVry, uint16_t rightVrx, uint16_t rightVry) {
  bleGamepad.setX(leftVrx);
  bleGamepad.setY(leftVry);
  bleGamepad.setZ(rightVrx);
  bleGamepad.setRX(rightVry);
}

